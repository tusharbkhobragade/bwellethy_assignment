package com.bwellthy.model;

import java.util.ArrayList;

/**
 * Created by tushar.khobragade on 4/6/2016.
 */
public class BWellthyWordList {

    private ArrayList<BWellthyWord> words;

    public ArrayList<BWellthyWord> getbWellthyWordList() {
        return words;
    }

    public void setbWellthyWordList(ArrayList<BWellthyWord> bWellthyWordList) {
        this.words = bWellthyWordList;
    }
}
