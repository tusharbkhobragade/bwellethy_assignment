package com.bwellthy.services.impl;

import com.bwellthy.model.BWellthyWord;
import com.bwellthy.model.BWellthyWordList;
import com.bwellthy.services.BWellthyService;
import com.bwellthy.util.BWellthyConstant;
import com.bwellthy.util.HttpUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class WebDataServiceImpl extends BWellthyService implements
        WebDataService {
    private Gson gson;

    public WebDataServiceImpl(ServiceManager serviceManager) {
        super(serviceManager);
    }

    @Override
    public void init() {
        super.init();
        initGson();
    }

    private void initGson() {
        gson = new Gson();
    }

    @Override
    public ArrayList<BWellthyWord> getListOfWords() {

        String url = BWellthyConstant.API_BASE_URL + BWellthyConstant.URL_GET_WORDS;

        try {
            HttpUtil httpUtil = new HttpUtil();
            String result = httpUtil.doGet(url);
            Type type = new TypeToken<BWellthyWordList>(){}.getType();
            BWellthyWordList bWellthyWordList = gson.fromJson(result, type);
            return bWellthyWordList.getbWellthyWordList();
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}