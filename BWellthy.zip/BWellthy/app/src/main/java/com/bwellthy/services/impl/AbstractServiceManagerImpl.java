package com.bwellthy.services.impl;

import com.bwellthy.services.BWellthyService;

import java.util.HashMap;

public class AbstractServiceManagerImpl implements ServiceManager {
	private ServiceContext serviceContext;
	private HashMap<Class<?>, Object> services;

	private static final Class<?>[] DefaultServices = {
			WebDataServiceImpl.class, LocalDataServiceImpl.class };

	public AbstractServiceManagerImpl(ServiceContext serviceContext)
			throws Exception {
		this(serviceContext, DefaultServices);
	}

	public AbstractServiceManagerImpl(ServiceContext serviceContext,
			Class<?>[] defaultService) throws Exception {
		this.serviceContext = serviceContext;
		services = new HashMap<Class<?>, Object>();
		for (Class<?> cls : defaultService) {
			BWellthyService service = (BWellthyService) cls
					.getConstructor(ServiceManager.class).newInstance(
							AbstractServiceManagerImpl.this);
			service.init();
			services.put(cls, service);
		}
	}

	@Override
	public ServiceContext getServiceContext() {
		return serviceContext;
	}

	@Override
	public WebDataService getWebDataService() {
		return (WebDataService) services.get(WebDataServiceImpl.class);
	}

	@Override
	public LocalDataService getLocalDataService() {
		return (LocalDataService) services.get(LocalDataServiceImpl.class);
	}

}
