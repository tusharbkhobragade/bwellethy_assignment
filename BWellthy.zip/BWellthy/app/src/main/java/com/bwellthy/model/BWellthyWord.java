package com.bwellthy.model;

/**
 * Created by tushar.khobragade on 4/6/2016.
 */
public class BWellthyWord {

    private long id;
    private String word;
    private long variant;
    private String meaning;
    private float ratio;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public long getVariant() {
        return variant;
    }

    public void setVariant(long variant) {
        this.variant = variant;
    }

    public String getMeaning() {
        return meaning;
    }

    public void setMeaning(String meaning) {
        this.meaning = meaning;
    }

    public float getRatio() {
        return ratio;
    }

    public void setRatio(float ratio) {
        this.ratio = ratio;
    }
}
