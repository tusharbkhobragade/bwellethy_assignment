package com.bwellthy.util;

public class BWellthyVersionTimeStamps {
	public static final String Version000001 = "20140117130404";
}
