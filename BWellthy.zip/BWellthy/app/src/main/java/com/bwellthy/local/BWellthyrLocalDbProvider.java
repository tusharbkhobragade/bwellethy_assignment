package com.bwellthy.local;

import com.bwellthy.local.tables.LocalBWellthyWords;
import com.bwellthy.util.BWellthyVersionTimeStamps;
import com.bwellthy.util.DBIdentifiers;
import com.gaoshin.sorma.AnnotatedORM;
import com.gaoshin.sorma.annotation.AbstractORMContentProvider;
import com.gaoshin.sorma.annotation.AnnotatedORMDefinition;
import com.gaoshin.sorma.annotation.ORMMapping;

@ORMMapping(dbname = DBIdentifiers.DB_NAME, yyyyMMddHHmmss = BWellthyVersionTimeStamps.Version000001, ORMClasses = {
        LocalBWellthyWords.class })
public class BWellthyrLocalDbProvider extends AbstractORMContentProvider {
    private static AnnotatedORMDefinition ormDefinition;
    private static AnnotatedORM orm;

    @Override
    protected void setOrmDefinition(AnnotatedORMDefinition ormDefinition) {
        System.out.println("set AnnotatedORMDefinition");
        synchronized (BWellthyrLocalDbProvider.class) {
            if (BWellthyrLocalDbProvider.ormDefinition == null) {
                BWellthyrLocalDbProvider.ormDefinition = ormDefinition;
            }

            if (BWellthyrLocalDbProvider.orm == null) {
                BWellthyrLocalDbProvider.orm = new AnnotatedORM(
                        ormDefinition);
            }
        }
    }

    public static AnnotatedORMDefinition getOrmDefinition() {
        synchronized (BWellthyrLocalDbProvider.class) {
            if (BWellthyrLocalDbProvider.ormDefinition == null) {
                System.out.println("ormDefinition is null. set it now");
                BWellthyrLocalDbProvider.ormDefinition = new AnnotatedORMDefinition(
                        BWellthyrLocalDbProvider.class);
            }

            if (BWellthyrLocalDbProvider.orm == null) {
                System.out.println("orm is null. set it now");
                BWellthyrLocalDbProvider.orm = new AnnotatedORM(
                        ormDefinition);
            }

            return ormDefinition;
        }
    }

    public static AnnotatedORM getOrm() {
        synchronized (BWellthyrLocalDbProvider.class) {
            if (BWellthyrLocalDbProvider.ormDefinition == null) {
                BWellthyrLocalDbProvider.ormDefinition = new AnnotatedORMDefinition(
                        BWellthyrLocalDbProvider.class);
            }

            if (BWellthyrLocalDbProvider.orm == null) {
                BWellthyrLocalDbProvider.orm = new AnnotatedORM(
                        ormDefinition);
            }

            return orm;
        }
    }
}
