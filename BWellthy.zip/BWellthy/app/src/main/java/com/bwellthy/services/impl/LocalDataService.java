package com.bwellthy.services.impl;

import com.bwellthy.model.BWellthyWord;

import java.util.ArrayList;

public interface LocalDataService {

    public void addBWellthyWords(ArrayList<BWellthyWord> bWellthyWordArrayList);
    public ArrayList<BWellthyWord> getBWellthyWordsList();
    public int getWordsCount();
}