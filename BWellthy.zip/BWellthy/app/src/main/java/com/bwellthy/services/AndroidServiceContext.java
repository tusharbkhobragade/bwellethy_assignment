package com.bwellthy.services;

import android.app.Application;

import com.bwellthy.services.impl.ServiceContext;
import com.gaoshin.sorma.AndroidContentResolver;
import com.gaoshin.sorma.SormaContentResolver;

public class AndroidServiceContext implements ServiceContext {
	private Application mApp;
	private SormaContentResolver contentResolver;
	
	public AndroidServiceContext(Application app) {
		mApp = app;
		this.contentResolver = new AndroidContentResolver(
				app.getContentResolver());
	}

	@Override
	public Application getApplication() {
		return mApp;
	}
	
	@Override
	public SormaContentResolver getContentResolver() {
		return contentResolver;
	}
}
