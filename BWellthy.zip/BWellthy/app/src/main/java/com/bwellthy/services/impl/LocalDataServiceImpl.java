package com.bwellthy.services.impl;

import com.bwellthy.local.BWellthyrLocalDbProvider;
import com.bwellthy.local.tables.LocalBWellthyWords;
import com.bwellthy.model.BWellthyWord;
import com.bwellthy.services.BWellthyService;
import com.bwellthy.util.Util;
import com.gaoshin.sorma.AnnotatedORM;
import com.gaoshin.sorma.reflection.ReflectionUtil;

import java.util.ArrayList;
import java.util.List;

public class LocalDataServiceImpl extends BWellthyService implements
        LocalDataService {
    protected AnnotatedORM orm;

    public LocalDataServiceImpl(ServiceManager serviceManager) {
        super(serviceManager);
        orm = BWellthyrLocalDbProvider.getOrm();
        orm.setContentResolver(serviceManager.getServiceContext()
                .getContentResolver());
    }

    @Override
    public void init() {
        super.init();
    }

    @Override
    public void addBWellthyWords(ArrayList<BWellthyWord> bWellthyWordArrayList) {

        List<LocalBWellthyWords> savedList = orm.getObjectList(
                LocalBWellthyWords.class, "1=1", null);
        if (!Util.isNullOrEmptyList(savedList)) {
            orm.delete(LocalBWellthyWords.class, "1=1", null);
        }
        List<LocalBWellthyWords> localBWellthyWordsArrayList =
                new ArrayList<LocalBWellthyWords>();
        for (BWellthyWord bWellthyWord : bWellthyWordArrayList) {
            LocalBWellthyWords localBWellthyWords = new LocalBWellthyWords();
            ReflectionUtil.copy(localBWellthyWords, bWellthyWord);
            localBWellthyWordsArrayList.add(localBWellthyWords);
        }
        orm.insert(localBWellthyWordsArrayList);
    }

    @Override
    public ArrayList<BWellthyWord> getBWellthyWordsList() {
        List<LocalBWellthyWords> list = orm.getObjectList(
                LocalBWellthyWords.class, "1=1", null);
        if (!Util.isNullOrEmptyList(list)) {
            ArrayList<BWellthyWord> bWellthyWordArrayList = new ArrayList<BWellthyWord>();
            for (LocalBWellthyWords localBWellthyWords : list) {
                BWellthyWord outlet = new BWellthyWord();
                ReflectionUtil.copy(outlet, localBWellthyWords);
                bWellthyWordArrayList.add(outlet);
            }
            return bWellthyWordArrayList;
        }
        return null;
    }

    @Override
    public int getWordsCount() {
        int count = orm.count(
                LocalBWellthyWords.class, "1=1", null);
        return count;
    }
}
