package com.bwellthy.activity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import com.bwellthy.BWellthyApplication;
import com.bwellthy.model.BWellthyWord;
import com.bwellthy.util.Util;

import java.util.ArrayList;

public class SplashActivity extends AppCompatActivity {

    private BWellthyApplication mBWellthyApplication;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        mBWellthyApplication = (BWellthyApplication)getApplication();
        mContext = SplashActivity.this;
        initialization();
    }

    private void initialization() {
        // get list of words if local data not available
        if (mBWellthyApplication.getServiceManager().getLocalDataService()
                .getWordsCount() == 0) {
            getWordsList();
        }else {
            startNextActivity();
        }
    }

    private void getWordsList() {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                if (Util.isNetworkAvailable(mContext)) {
                    ArrayList<BWellthyWord> bWellthyWordArrayList = mBWellthyApplication.getServiceManager()
                            .getWebDataService().getListOfWords();
                    if (!Util.isNullOrEmptyList(bWellthyWordArrayList)){
                        mBWellthyApplication.getServiceManager().getLocalDataService()
                                .addBWellthyWords(bWellthyWordArrayList);
                    }
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                startNextActivity();
            }
        }.execute();
    }

    private void startNextActivity(){
        // start new activity
        startActivity(new Intent(mContext, HomeActivity.class));
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_splash, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
