package com.bwellthy.services.impl;

import android.app.Application;

import com.gaoshin.sorma.SormaContentResolver;

public interface ServiceContext {
	Application getApplication();
	SormaContentResolver getContentResolver();
}
