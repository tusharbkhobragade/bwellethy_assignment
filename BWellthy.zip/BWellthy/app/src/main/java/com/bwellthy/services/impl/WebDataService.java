package com.bwellthy.services.impl;

import com.bwellthy.model.BWellthyWord;

import java.util.ArrayList;

public interface WebDataService {

    public ArrayList<BWellthyWord> getListOfWords();
}
