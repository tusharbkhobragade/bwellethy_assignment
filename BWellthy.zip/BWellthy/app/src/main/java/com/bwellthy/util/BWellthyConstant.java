package com.bwellthy.util;

/**
 * Created by tushar.khobragade on 4/6/2016.
 */
public class BWellthyConstant {

    public static final String API_BASE_URL = "http://appsculture.com/vocab/";
    public static final String URL_GET_WORDS = "words.json";
    public static final String URL_GET_IMAGES = "images/";
    public static final String URL_PNG = ".png";
}
