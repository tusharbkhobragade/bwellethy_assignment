package com.bwellthy.services.impl;

public interface ServiceManager {
	ServiceContext getServiceContext();

	WebDataService getWebDataService();

	LocalDataService getLocalDataService();
}
