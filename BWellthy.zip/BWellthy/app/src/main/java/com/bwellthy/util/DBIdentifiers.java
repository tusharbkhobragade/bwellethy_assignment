package com.bwellthy.util;

public class DBIdentifiers {
	public static final String DB_NAME = "BWellthyLocalDB";
	public static final String TABLE_BWELLTHEY_WORDS = "localBWelltheyWords";
}
