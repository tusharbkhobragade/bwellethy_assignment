package com.bwellthy.local.tables;

import com.bwellthy.util.DBIdentifiers;
import com.gaoshin.sorma.annotation.Table;

@Table(name = DBIdentifiers.TABLE_BWELLTHEY_WORDS, create = { "create table IF NOT EXISTS "
		+ DBIdentifiers.TABLE_BWELLTHEY_WORDS
		+ " ("
		+ " id varchar(130)"
		+ ", word varchar(130)"
		+ ", variant varchar(130)"
		+ ", meaning varchar(130)"
		+ ", ratio varchar(130)" + ")", })

public class LocalBWellthyWords {
	private Long id;
	private String word;
	private Long variant;
	private String meaning;
	private Float ratio;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public Long getVariant() {
		return variant;
	}

	public void setVariant(Long variant) {
		this.variant = variant;
	}

	public String getMeaning() {
		return meaning;
	}

	public void setMeaning(String meaning) {
		this.meaning = meaning;
	}

	public Float getRatio() {
		return ratio;
	}

	public void setRatio(Float ratio) {
		this.ratio = ratio;
	}
}
