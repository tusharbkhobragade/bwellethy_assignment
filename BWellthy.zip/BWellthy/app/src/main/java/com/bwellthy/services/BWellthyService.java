package com.bwellthy.services;

import com.bwellthy.services.impl.ServiceContext;
import com.bwellthy.services.impl.ServiceManager;

public class BWellthyService {
	protected ServiceContext context;
	protected ServiceManager serviceManager;

	public BWellthyService(ServiceManager serviceManager) {
		this.serviceManager = serviceManager;
		this.context = serviceManager.getServiceContext();
	}

	protected ServiceContext getContext() {
		return context;
	}

	protected ServiceManager getServiceManager() {
		return serviceManager;
	}

	public void init() {}

	public void unsubscribeApp() {}
}
