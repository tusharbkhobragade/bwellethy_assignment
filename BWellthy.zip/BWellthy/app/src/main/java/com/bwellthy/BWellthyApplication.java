package com.bwellthy;


import android.app.Application;
import android.os.AsyncTask;

import com.bwellthy.services.AndroidServiceContext;
import com.bwellthy.services.impl.AbstractServiceManagerImpl;
import com.bwellthy.services.impl.ServiceManager;

public class BWellthyApplication extends Application {

	private AndroidServiceContext serviceContext;
	private ServiceManager serviceManager;

	@Override
	public void onCreate() {
		super.onCreate();

		serviceContext = new AndroidServiceContext(this);
		init();
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
	}

	public void init() {
		new AsyncTask<Void, Void, Void>() {
			
			protected void onPreExecute() {
			};

			@Override
			protected Void doInBackground(Void... params) {
				synchronized (this) {
					try {
						serviceManager = new AbstractServiceManagerImpl(serviceContext);
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
					return null;
				}
			}

			@Override
			protected void onPostExecute(Void result) {
				super.onPostExecute(result);
			}

		}.execute(null, null, null);
	}
	
	public ServiceManager getServiceManager() {
		while (serviceManager == null) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		synchronized (this) {
			return serviceManager;
		}
	}
}
