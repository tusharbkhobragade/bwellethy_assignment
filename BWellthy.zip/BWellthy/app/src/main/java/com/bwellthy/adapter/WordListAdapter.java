package com.bwellthy.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bwellthy.activity.R;
import com.bwellthy.model.BWellthyWord;
import com.bwellthy.util.BWellthyConstant;
import com.bwellthy.util.lazyloading.ImageLoader;

import java.util.ArrayList;

/**
 * Created by tushar.khobragade on 4/6/2016.
 */
public class WordListAdapter extends RecyclerView
        .Adapter<WordListAdapter
        .DataObjectHolder> {
    private static String LOG_TAG = WordListAdapter.class.getSimpleName();
    private ArrayList<BWellthyWord> mDataset;
    private ItemClickListener itemClickListener;
    public ImageLoader imageLoader;

    public class DataObjectHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {
        ImageView labelImage;
        TextView label;
        TextView meaning_text;

        public DataObjectHolder(View itemView) {
            super(itemView);
            labelImage = (ImageView) itemView.findViewById(R.id.word_image);
            label = (TextView) itemView.findViewById(R.id.textView);
            meaning_text = (TextView) itemView.findViewById(R.id.textView2);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            itemClickListener.onItemClick(getPosition(), v);
        }
    }

    public void setOnItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public WordListAdapter(Context context, ArrayList<BWellthyWord> myDataset) {
        mDataset = myDataset;
        // Create ImageLoader object to download and show image in list
        // Call ImageLoader constructor to initialize FileCache
        imageLoader = new ImageLoader(context.getApplicationContext());
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent,
                                               int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycleriew_item, parent, false);

        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(DataObjectHolder holder, int position) {
        BWellthyWord bWellthyWord = mDataset.get(position);
        holder.label.setText(bWellthyWord.getWord());
        holder.meaning_text.setText(bWellthyWord.getMeaning());
        ImageView image = holder.labelImage;
        displayImage(image, bWellthyWord);
    }

    private void displayImage(ImageView image, BWellthyWord bWellthyWord) {
        String url = BWellthyConstant.API_BASE_URL
                + BWellthyConstant.URL_GET_IMAGES + bWellthyWord.getId() + BWellthyConstant.URL_PNG;
        //DisplayImage function from ImageLoader Class
        imageLoader.DisplayImage(url, image);
    }

    public void addItem(BWellthyWord dataObj, int index) {
        mDataset.add(dataObj);
        notifyItemInserted(index);
    }

    public void deleteItem(int index) {
        mDataset.remove(index);
        notifyItemRemoved(index);
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public interface ItemClickListener {
        public void onItemClick(int position, View v);
    }
}
